#ifndef TEACHER_H
#define TEACHER_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr); // ✅ Now it's inside the class
    ~MainWindow();

private:
    Ui::MainWindow *ui;

private slots:
    void on_pushButtonOpenForm1_clicked();
};

#endif // TEACHER_H
