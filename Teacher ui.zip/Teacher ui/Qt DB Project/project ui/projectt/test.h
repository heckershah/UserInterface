#ifndef TEST_H
#define TEST_H

#include <QDialog>

namespace Ui {
class SalaryForm;
}

class SalaryForm : public QDialog
{
    Q_OBJECT

public:
    explicit SalaryForm(QWidget *parent = nullptr);
    ~SalaryForm();

private:
    Ui::SalaryForm *ui;

private slots:
    void onMyButtonClicked();
};


#endif // TEST_H
