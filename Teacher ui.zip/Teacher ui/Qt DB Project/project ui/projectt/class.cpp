#include "class.h"
#include "ui_class.h"

Form1::Form1(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Form1)
{
    ui->setupUi(this);
}

Form1::~Form1()
{
    delete ui;
}
