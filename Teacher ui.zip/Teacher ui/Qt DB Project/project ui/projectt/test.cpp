#include "test.h"
#include "ui_test.h"
#include <QDebug> // For demonstration

SalaryForm::SalaryForm(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SalaryForm)
{
    ui->setupUi(this);
    // Connect the button's clicked signal to the slot
    connect(ui->pushButton, &QPushButton::clicked, this, &SalaryForm::onMyButtonClicked);
}

SalaryForm::~SalaryForm()
{
    delete ui;
}

void SalaryForm::onMyButtonClicked()
{
    // This code will be executed when the button is clicked
    qDebug() << "Button 'myButton' was clicked!";
    // Add your desired action here
}
