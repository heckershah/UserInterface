#ifndef CLASS_H
#define CLASS_H

#include <QDialog>

namespace Ui {
class Form1;
}

class Form1 : public QDialog
{
    Q_OBJECT

public:
    explicit Form1(QWidget *parent = nullptr);
    ~Form1();

private:
    Ui::Form1 *ui;
};

#endif // CLASS_H
