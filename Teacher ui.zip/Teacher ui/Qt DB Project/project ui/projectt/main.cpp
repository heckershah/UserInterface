#include "class.h"         // You can still keep this if you'll use it later
#include "Teacher.h"    // MainWindow will be the startup window

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainWindow mainWindow;  // Create MainWindow
    mainWindow.show();      // Show MainWindow first

    return a.exec();
}
