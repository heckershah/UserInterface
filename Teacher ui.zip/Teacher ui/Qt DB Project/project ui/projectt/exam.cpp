#include "exam.h"
#include "ui_exam.h"

Report::Report(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Report)
{
    ui->setupUi(this);
}

Report::~Report()
{
    delete ui;
}
