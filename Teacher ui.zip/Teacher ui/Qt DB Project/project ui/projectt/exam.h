#ifndef EXAM_H
#define EXAM_H

#include <QDialog>

namespace Ui {
class Report;
}

class Report : public QDialog
{
    Q_OBJECT

public:
    explicit Report(QWidget *parent = nullptr);
    ~Report();

private:
    Ui::Report *ui;
};

#endif // EXAM_H
