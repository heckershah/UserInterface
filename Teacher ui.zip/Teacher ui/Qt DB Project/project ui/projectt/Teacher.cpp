#include "class.h"

#include "Teacher.h"
#include "ui_Teacher.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}
void MainWindow::on_pushButtonOpenForm1_clicked()
{
    Form1 *form = new Form1(this); // Parent is optional
    form->show(); // Open Form1
}

MainWindow::~MainWindow()
{
    delete ui;
}
