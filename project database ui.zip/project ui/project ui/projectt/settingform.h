#ifndef SETTINGFORM_H
#define SETTINGFORM_H

#include <QDialog>

namespace Ui {
class settingform;
}

class settingform : public QDialog
{
    Q_OBJECT

public:
    explicit settingform(QWidget *parent = nullptr);
    ~settingform();

private:
    Ui::settingform *ui;
};

#endif // SETTINGFORM_H
