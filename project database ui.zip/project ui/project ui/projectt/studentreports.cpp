#include "studentreports.h"
#include "ui_studentreports.h"

Studentreports::Studentreports(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Studentreports)
{
    ui->setupUi(this);
}

Studentreports::~Studentreports()
{
    delete ui;
}
