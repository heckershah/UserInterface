#include "Employee.h"
#include "ui_Employee.h"

classesform::classesform(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::classesform)
{
    ui->setupUi(this);
}

classesform::~classesform()
{
    delete ui;
}
