#include "settingform.h"
#include "ui_settingform.h"

settingform::settingform(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::settingform)
{
    ui->setupUi(this);
}

settingform::~settingform()
{
    delete ui;
}
