#ifndef STDENTSFORM_H
#define STDENTSFORM_H

#include <QDialog>

namespace Ui {
class stdentsform;
}

class stdentsform : public QDialog
{
    Q_OBJECT

public:
    explicit stdentsform(QWidget *parent = nullptr);
    ~stdentsform();

private:
    Ui::stdentsform *ui;
};

#endif // STDENTSFORM_H
