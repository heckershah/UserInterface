#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <QDialog>

namespace Ui {
class classesform;
}

class classesform : public QDialog
{
    Q_OBJECT

public:
    explicit classesform(QWidget *parent = nullptr);
    ~classesform();

private:
    Ui::classesform *ui;
};

#endif // EMPLOYEE_H
