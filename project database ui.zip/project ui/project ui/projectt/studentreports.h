#ifndef STUDENTREPORTS_H
#define STUDENTREPORTS_H

#include <QDialog>

namespace Ui {
class Studentreports;
}

class Studentreports : public QDialog
{
    Q_OBJECT

public:
    explicit Studentreports(QWidget *parent = nullptr);
    ~Studentreports();

private:
    Ui::Studentreports *ui;
};

#endif // STUDENTREPORTS_H
