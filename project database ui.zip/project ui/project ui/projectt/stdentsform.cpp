#include "stdentsform.h"
#include "ui_stdentsform.h"

stdentsform::stdentsform(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::stdentsform)
{
    ui->setupUi(this);
}

stdentsform::~stdentsform()
{
    delete ui;
}
