#include "mainwindow.h"  // Make sure this points to the right header file for MainWindow
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainWindow w;  // This creates the MainWindow instance
    w.show();      // This shows the MainWindow

    return a.exec();
}
