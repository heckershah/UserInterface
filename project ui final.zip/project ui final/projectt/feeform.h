#ifndef FEEFORM_H
#define FEEFORM_H

#include <QDialog>

namespace Ui {
class Feeform;
}

class Feeform : public QDialog
{
    Q_OBJECT

public:
    explicit Feeform(QWidget *parent = nullptr);
    ~Feeform();

private:
    Ui::Feeform *ui;
};

#endif // FEEFORM_H
