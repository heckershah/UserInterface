#include "feeform.h"
#include "ui_feeform.h"

Feeform::Feeform(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Feeform)
{
    ui->setupUi(this);
}

Feeform::~Feeform()
{
    delete ui;
}
