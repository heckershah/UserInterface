#include "reportexam.h"
#include "ui_reportexam.h"

reportexam::reportexam(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::reportexam)
{
    ui->setupUi(this);
}

reportexam::~reportexam()
{
    delete ui;
}
