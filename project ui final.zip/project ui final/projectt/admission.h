#ifndef ADMISSION_H
#define ADMISSION_H

#include <QDialog>

namespace Ui {
class admission;
}

class admission : public QDialog
{
    Q_OBJECT

public:
    explicit admission(QWidget *parent = nullptr);
    ~admission();

private:
    Ui::admission *ui;
};

#endif // ADMISSION_H
