#include "admission.h"
#include "ui_admission.h"

admission::admission(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::admission)
{
    ui->setupUi(this);
}

admission::~admission()
{
    delete ui;
}
