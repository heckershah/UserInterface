#ifndef STUDENTDETAIL_H
#define STUDENTDETAIL_H

#include <QDialog>

namespace Ui {
class StudentDetail;
}

class StudentDetail : public QDialog
{
    Q_OBJECT

public:
    explicit StudentDetail(QWidget *parent = nullptr);
    ~StudentDetail();

private:
    Ui::StudentDetail *ui;
};

#endif // STUDENTDETAIL_H
