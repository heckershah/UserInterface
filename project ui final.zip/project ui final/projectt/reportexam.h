#ifndef REPORTEXAM_H
#define REPORTEXAM_H

#include <QDialog>

namespace Ui {
class reportexam;
}

class reportexam : public QDialog
{
    Q_OBJECT

public:
    explicit reportexam(QWidget *parent = nullptr);
    ~reportexam();

private:
    Ui::reportexam *ui;
};

#endif // REPORTEXAM_H
