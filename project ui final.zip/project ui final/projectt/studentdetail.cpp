#include "studentdetail.h"
#include "ui_studentdetail.h"

StudentDetail::StudentDetail(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::StudentDetail)
{
    ui->setupUi(this);
}

StudentDetail::~StudentDetail()
{
    delete ui;
}
